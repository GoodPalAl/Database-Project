package profile;

import java.util.Scanner;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import util.Validation;
import profile.UserProfile;


public class PetProfile 
{
    public static void addPetInfo()
    {
        String petType, petName, owner;
        int petID = 1, birthYear;
        char c;

        petID = Validation.getPetID();

        System.out.println("Please enter your pet's name: ");
        petName = Validation.getPetName();

        System.out.println("Enter what kind of animal your pet is: ");
        petType = Validation.getPetType();

        System.out.println("How old is your pet? (in years) ");
        birthYear = Validation.getPetBirthYear();

    }
    public static void displayPetInfo()
    {
        try 
        {
			final String QUERY =
				"SELECT petid, pettype, petname, birthyear, owner" +
				"FROM pets WHERE owner = '" +
                Validation.curUsername + "';";

            ResultSet rs = Validation.statement.executeQuery(QUERY);

            if (rs.next()) {
                System.out.println("petid: " + rs.getString("petid"));
                System.out.println("pettype: " + rs.getString("pettype"));
                System.out.println("petname: " + rs.getString("petname"));
                System.out.println("birthyear: " +  rs.getString("birthyear"));
                System.out.println("owner: " + rs.getString("owner"));
            }
            else
                System.err.println("Internal error finding entry matching "
                                        + "owner.");            
        }
        catch (java.sql.SQLException e) 
        {
            System.err.println(e);
            System.exit(-1);
        }
    }
}