package search;

import java.util.Scanner;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import util.Validation;



public class Search {

    public static char goToSearch()
    {
        char c;
		

        
		// Promp user if they would like to navigate to another page
		System.out.println(Validation.OPTIONS);
		c = Validation.input.nextLine().toLowerCase().charAt(0);
		System.out.println();
		while (!Validation.isValidOption(c)) {
			System.out.println("Please enter a valid option." +
									Validation.OPTIONS);
			c = Validation.input.nextLine().toLowerCase().charAt(0);
			System.out.println();
		}
        return c;
    }

}