package search;

import java.util.Scanner;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import util.Validation;



public class Offer 
{
    public static void createOffer()
    {
        String desc, dateStart, timeStart, dateEnd, timeEnd;
        double payment;
        int offerID, sitting;

        offerID = Validation.getOfferID();

        System.out.println("Which of your pets is this offer for? ");
        sitting = Validation.getSitting();
        
        System.out.println("When does your pet need to be sat? ");
        dateStart = Validation.getOfferStartDate();
        timeStart = Validation.getOfferStartTime();
        dateEnd = Validation.getOfferEndDate();
        timeEnd = Validation.getOfferEndTime();

        System.out.println("Enter payment amount: $");
        payment = Validation.getPayment();

        System.out.println("Please provide any additional information " + 
                                "regarding this post. Limit of " + 
                                Validation.DESC_MAX_LENGTH + " characters." +
                                "Press enter when done.\n");
        desc = Validation.getDescription();

        String insertCMD = "INSERT INTO offers (offerid, description, " +
                                "tsposted, tsstart, tsend, payment, " +
                                "sitting)" +
                                "VALUES(" + offerID + ",'"+ desc +
                                "', NOW() , DATE '" + dateStart + 
                                "' + TIME '" + timeStart + 
                                "',  DATE '" + dateEnd + 
                                "' + TIME '" + timeEnd +
                                "', " + payment + ", " + sitting + ");";

		try {
			Validation.statement.executeUpdate(insertCMD);
		}
		catch (java.sql.SQLException e) {
			System.err.println(e);
			System.exit(-1);
		}
    }

    public static void displayOfferInfo()
    {
        try
        {
			ResultSet rs
				= Validation.statement.executeQuery("SELECT username, fullname, " +
														"email, issitter, isowner, " +
														"rating, tsjoined, city, " +
				                                    	"state FROM accounts WHERE " +
														"username = '" +
														Validation.curUsername + "';");
			if (rs.next()) {
				System.out.println("username: " + rs.getString("username"));
				System.out.println("fullname: " + rs.getString("fullname"));
				System.out.println("email: " + rs.getString("email"));
				System.out.println("pet sitter?: " +
													 (rs.getBoolean("issitter") ? "yes" : "no"));
				System.out.println("pet owner?: " +
													 (rs.getBoolean("isowner") ? "yes" : "no"));
				System.out.println("rating: " +
													 (rs.getDouble("rating") == 0.0 ? "none" :
														String.valueOf(rs.getDouble("rating"))));
				System.out.println("joined: " +
													 Validation.FORMAT.format(new Date
																				 (rs.getTimestamp("tsjoined").
																					getTime())));
				System.out.println("city: " + rs.getString("city"));
				System.out.println("state: " + rs.getString("state"));
			}
			else
				System.err.println("Internal error finding entry matching "
													 + "username.");
        }
		catch (java.sql.SQLException e) {
			System.err.println(e);
			System.exit(-1);
		}
    }
}
