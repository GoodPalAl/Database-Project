package search;

import java.util.Scanner;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import util.Validation;
import profile.UserProfile;
import profile.PetProfile;


public class Offer 
{
	public static int curOfferID;
	// EDITED BY AL 4 24 2020
	public static char goToCreateOffer()
	{
		createOffer();

		char c;		
		// Promp user if they would like to navigate to another page
		System.out.println(Validation.OPTIONS);
		c = Validation.input.nextLine().toLowerCase().charAt(0);
		System.out.println();
		while (!Validation.isValidOption(c)) {
			System.out.println("Please enter a valid option." +
												Validation.OPTIONS);
			c = Validation.input.nextLine().toLowerCase().charAt(0);
			System.out.println();
		}
		return c;
	}
	//Editted by Sydney
    public static void createOffer()
    {
        String desc, dateStart, timeStart, dateEnd, timeEnd;
        double payment; 
        int offerID, sitting;

        offerID = 9; //Validation.getOfferID();

        System.out.println("Which of your pets is this offer for? ");
        sitting = Validation.getSitting();
        
        System.out.println("When does your pet need to be sat? ");
        dateStart = Validation.getOfferStartDate();
        timeStart = Validation.getOfferStartTime();
        dateEnd = Validation.getOfferEndDate();
        timeEnd = Validation.getOfferEndTime();

        System.out.println("Enter payment amount: $");
        payment = Validation.getPayment();

        System.out.println("Please provide any additional information " + 
                                "regarding this post. Limit of " + 
                                Validation.DESC_MAX_LENGTH + " characters." +
                                "Press enter when done.\n");
        desc = Validation.getDescription();

        String insertCMD = "INSERT INTO offers (offerid, description, " +
                                "tsposted, tsstart, tsend, payment, " +
                                "sitting)" +
                                "VALUES(" + offerID + ",'"+ desc +
                                "', NOW() , DATE '" + dateStart + 
                                "' + TIME '" + timeStart + 
                                "',  DATE '" + dateEnd + 
                                "' + TIME '" + timeEnd +
                                "', " + payment + ", " + sitting + ");";

		Validation.updateSQL(insertCMD);
	}
	
	//Added by Al
	//Editted by Sydney
	public static String getNameFromPetID(int sitting){
		try{
		  ResultSet rs = Validation.statement.executeQuery("SELECT petName FROM pets WHERE petID = " + sitting + " ;");
		  return rs.getString("petName");
		}
		catch (java.sql.SQLException e) {
		  System.err.println(e);
		  System.exit(-1);
		}
		return null;
	}

	//Editted by Sydney
    public static void displayOfferInfo()
    {
        try
        {
			ResultSet rs
				= Validation.statement.executeQuery("SELECT description, " +
														"tsposted, tsstart, tsend, " +
														"payment, sitting " +
				                                    	"FROM offer WHERE " +
														"offerid = '" +
														curOfferID + "';");
			if (rs.next()) {
				System.out.println("Description: " + rs.getString("description"));
				System.out.println("Time posted: " + Validation.FORMAT.format(new Date
														(rs.getTimestamp("tsposted").
				   											getTime())));
				System.out.println("Start time: " +  Validation.FORMAT.format(new Date
														(rs.getTimestamp("tsstart").
															   getTime())));
				System.out.println("End time: " +  Validation.FORMAT.format(new Date
														(rs.getTimestamp("tsend").
																getTime())));
				System.out.println("Payment: " +
													 rs.getDouble("payment"));
				System.out.println("Sitting: " +
													getNameFromPetID(rs.getInt("sitting")));  //FIXME trying to connect to get petname
			}
			else
				System.err.println("Internal error finding entry matching "
													 + "offerID.");
        }
		catch (java.sql.SQLException e) {
			System.err.println(e);
			System.exit(-1);
		}
    }
}
