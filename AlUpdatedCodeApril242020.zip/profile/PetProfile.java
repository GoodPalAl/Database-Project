package profile;

import java.util.Scanner;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.lang.reflect.Method;
import java.sql.Statement;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.text.SimpleDateFormat;
import java.util.*;
import util.Validation;
import profile.UserProfile;
import profile.PetProfile;


public class PetProfile
{
	// EDITED 4 24 2020
	protected static int curPetID;

	public static void goToPetProfile()
	{
		//System.out.println("hek");
		displayPetInfo(null);
		String response, query;
		boolean petFound = false;
		try {	// FIXME: emma told me how to reduce the number of try-catches when using "rs" and i forgot what it was -.-;
			do {
				System.out.print("Enter the name of the pet you would like to edit: ");
				response = Validation.input.nextLine();
				query = "SELECT petID FROM pets WHERE owner = '" +
							Validation.curUsername + "' AND petName = '" + 
							response + "';";
				// FIXME: Need to implement code that will check if pet name already exists when inserting new pets for a user.
				petFound = Validation.numMatches(query, "pets") == 1 ? true : false;	
				if (!petFound)
				{
					System.out.print("Invalid option. \nEnter the name of the pet you would like to edit: ");
					response = Validation.input.nextLine();
				}
			} while (!petFound);
			ResultSet rs = Validation.querySQL(query);
			while(rs.next())
			{
				curPetID = rs.getInt("petID");
				editPetInfo();
			}
			rs.close();
		}
		catch (java.sql.SQLException e) {
			System.err.println(e);
			System.exit(-1);
		}
	}

	// Create generic update statement based on which field to update for
	// curPetID. Intended for use with boolean values.
	private static String genUpdateSQL(String field, String update, int petID) {
		return "UPDATE pets SET " + field + " = " + update + " WHERE "
			+ "petID = " + petID + ";";
	}

	// Map of characters to the corresponding method to update the associated
	// pet data
	final static Map<Character, Method> updatePetField = 
			Collections.unmodifiableMap(new HashMap<Character, Method>() {{
		try {
			put('t', PetProfile.class.getMethod("updatePetType"));
			put('n', PetProfile.class.getMethod("updatePetName"));
			put('a', PetProfile.class.getMethod("updatePetAge"));
			put('d', PetProfile.class.getMethod("deletePet"));
		}
		catch (java.lang.NoSuchMethodException e) {
			System.err.println(e);
			System.exit(-1);
		}
	}});

	final public static void deletePet()
	{
		;
	}

	final public static void updatePetType() {
		System.out.print("Enter what kind of animal your pet is: ");
		String newPetType = "'" + Validation.getPetType() + "'";
		Validation.updateSQL(genUpdateSQL("petType", newPetType,
											curPetID));
	}

	final public static void updatePetName() {
		System.out.print("Enter what kind of animal your pet is: ");
		String newPetType = "'" + Validation.getPetType() + "'";
		Validation.updateSQL(genUpdateSQL("petType", newPetType,
											curPetID));
	}

	// TODO: should age_to_birth_year() get involved here? and how?
	final public static void updatePetAge() {
		System.out.print("Enter age of your pet: ");
		String newPetType = "'" + Validation.getPetAge() + "'";
		Validation.updateSQL(genUpdateSQL("petAge", newPetType,
											curPetID));
	}

    public static void editPetInfo()
	{
		displayPetInfo(curPetID);
		final String PET_OPTIONS = 
			"Enter 't' for pet type, \n" +
			"'n' for pet name, \n" +
			"'a' for age, \n" +
			"'d' to delete this pet, \n" +
			"or 'q' to cancel editing.";

		char response;
		boolean badOption = false;

		System.out.println("Please enter which part of your pet's information you " +
								"would like to update:\n" + PET_OPTIONS);
		response = Validation.input.nextLine().charAt(0);
		do {
			if (badOption) {
				System.out.println("Invalid option.\n" + 
										"Please enter which " +
										"part of your pet's information " +
										"you would like to update:\n" + PET_OPTIONS);
				response = Validation.input.nextLine().charAt(0);
			}
			try {
				updatePetField.get(response).invoke(null);
				badOption = false;
			}
			// Will catch case where a bad key is passed to
			// updateUserField map
			catch (java.lang.ReflectiveOperationException e) {
				badOption = true;
			}
		} while (badOption);
	}
    public static void addPetInfo()
    {
		String petType, petName;
		int age;

		System.out.print("Please enter your pet's name: ");
		petName = Validation.getPetName();

		System.out.print("Enter what kind of animal your pet is: ");
		petType = Validation.getPetType();

		System.out.print("How old is your pet? (in years) ");
		age = Validation.getPetAge();

		String insertCMD = "INSERT INTO pets (pettype, petname, " +
			"birthyear, owner)" +
			"VALUES('" + petType +
			"', '" + petName + "', " + age +	// FIXME: should "age" be "age_to_birthyear("+age+")" ?
			", '" + Validation.curUsername + "');";
		Validation.updateSQL(insertCMD);
	}
	// If petID == NULL -> display all pets, otherwise display pet matching petID
	public static void displayPetInfo(Integer petID) {
		//System.out.println("AAAAAAAAAAAAAAAAAAAA");
		String query = "SELECT petname, pettype, birth_year_to_age(birthyear) as age " +
				   "FROM pets WHERE owner = '" + Validation.curUsername + "'" + 
				   (petID == null ? ";" : " AND petID = " + petID + ";");

		//System.out.println(query);
		
		try {
			int idk = Validation.numMatches(query);
			ResultSet rs = Validation.statement.executeQuery(query);

			int i;			
			for (i = 1; rs.next(); ++i) {
				if (idk > 1)
					System.out.println("Pet #" + i);
				System.out.println("petname: " + rs.getString("petname"));
				System.out.println("pettype: " + rs.getString("pettype"));
				int age = rs.getInt("age");
				if (age < 1)
					System.out.println("age: less than a year");
				else
					System.out.println("age: " + age + " years");
				System.out.println();
			}
			
			rs.close();
		}
		catch (java.sql.SQLException e) {
			System.err.println(e);
			System.exit(-1);
		}
	}
	//END OF AL EDIT
}
