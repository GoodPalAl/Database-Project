package profile;

import java.util.Scanner;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.*;
import util.Validation;
import profile.UserProfile;


public class PetProfile
{
	// EDITED 4 24 2020
    public static void editPetInfo()
	{
		final String PET_OPTIONS = 
			"Enter 't' for pet type, \n" +
			"'n' for pet name, \n" +
			"'a' for age, \n" +
			//"'d' to delete this pet, \n" +	FIXME : should this be a thing?
			"or 'q' to cancel editing.";

		char response;
		boolean badOption = false;

		System.out.println("Please enter which part of your pet's information you " +
								"would like to update:\n" + PET_OPTIONS);
		response = Validation.input.nextLine().charAt(0);
		do {
			if (badOption) {
				System.out.println("Invalid option.\n" + 
										"Please enter which " +
										"part of your pet's information " +
										"you would like to update:\n" + PET_OPTIONS);
				response = Validation.input.nextLine().charAt(0);
			}
			try {
				updatePetField.get(response).invoke(null);
				badOption = false;
			}
			// Will catch case where a bad key is passed to
			// updateUserField map
			catch (java.lang.ReflectiveOperationException e) {
				badOption = true;
			}
		} while (badOption);
	}
	// Map of characters to the corresponding method to update the associated
	// user data
	final static Map<Character, Method> updatePetField
		= Collections.unmodifiableMap(new HashMap<Character, Method>() {{
		try {
			put('t', PetProfile.class.getMethod("updatePetType"));
			put('n', PetProfile.class.getMethod("updatePetName"));
			put('a', PetProfile.class.getMethod("updateFullname"));
		}
		catch (java.lang.NoSuchMethodException e) {
			System.err.println(e);
			System.exit(-1);
		}
		}});
	// END OF EDITED
    public static void addPetInfo()
    {
			String petType, petName;
			int age;

			System.out.println("Please enter your pet's name: ");
			petName = Validation.getPetName();

			System.out.println("Enter what kind of animal your pet is: ");
			petType = Validation.getPetType();

			System.out.println("How old is your pet? (in years) ");
			age = Validation.getPetAge();

			String insertCMD = "INSERT INTO pets (pettype, petname, " +
				"birthyear, owner)" +
				"VALUES('" + petType +
				"', '" + petName + "', " + age +
				", '" + Validation.curUsername + "');";
			Validation.updateSQL(insertCMD);

    }
    public static void displayPetInfo()
    {
			try {
			ResultSet rs
				= Validation.querySQL("SELECT " +
										"petname, pettype, birth_year_to_age(birthyear) as age" +
										"FROM pets WHERE owner = '"
										+ Validation.curUsername + "';");
			if (rs.next()) {
				System.out.println("petname: " + rs.getString("petname"));
				System.out.println("pettype: " + rs.getString("pettype"));
				System.out.println("age: " + rs.getInt("age") + " years");
				System.out.println();
			}
			else
				System.err.println("Internal error finding entry matching "
													 + "owner.");
			}
			catch (java.sql.SQLException e) {
				System.err.println(e);
				System.exit(-1);
			}
		}
}
